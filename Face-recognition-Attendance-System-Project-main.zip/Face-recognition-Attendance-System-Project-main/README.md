# Face-recognition-Attendance-System-Project
Final Year Face recognition Attendance System Project 

### Youtube Implementation Video : https://youtu.be/tLhFaAurhGw

